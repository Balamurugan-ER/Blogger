*** This is being used to merge the two given webxml files generated using JspC **

*** That is, the content of the first file will be appended to the second file ***


Usage: java MergeWebXmlFiles <source-file> <target-file>
